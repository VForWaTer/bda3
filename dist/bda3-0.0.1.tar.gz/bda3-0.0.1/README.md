# BDA3

This package will be a Python implementation of algorithms from the book Bayesian Data Analysis by Gelamn et. al.